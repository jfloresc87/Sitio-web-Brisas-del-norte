<?php
/* =====================================================================
 *  CONFIGURACIÓN GENERAL  –  edita SOLO este archivo para cambiar datos
 * ===================================================================== */

// ---- Base de datos (créalas en cPanel, ver instrucciones) -------------
define('DB_HOST', 'localhost');
define('DB_USER', 'ulnlxkwm_junta');            // usuario MySQL creado en cPanel
define('DB_PASS', 'CAMBIAR_CLAVE_BDD');         // clave de ese usuario
define('DB_WEB',  'ulnlxkwm_brisas');           // BDD del sitio (usuarios, noticias, servicios)
define('DB_REC',  'ulnlxkwm_comprob');          // BDD APARTE para comprobantes

// ---- Sitio y correo ---------------------------------------------------
define('BASE_URL',   'https://brisasdelnorteuv8.cl');       // sin "/" final
define('MAIL_FROM',  'no-reply@brisasdelnorteuv8.cl');      // casilla del dominio (evita spam)
define('MAIL_TO',    'brisasdelnorteuv8@gmail.com'); // recibe los mensajes del formulario
define('INSTALL_KEY','cambia-esta-clave-de-instalacion'); // se pide al abrir /install.php

// ---- Datos de la junta (se usan en el sitio y en los comprobantes) ----
$JUNTA = [
  'nombre'    => 'Junta de Vecinos N°8 Brisas del Norte',   // <-- EDITAR
  'lema'      => 'Organizados por nuestro barrio',           // <-- EDITAR
  'direccion' => 'Calle Ejemplo 1234, Comuna, Región',       // <-- EDITAR
  'telefono'  => '+56 9 0000 0000',                          // <-- EDITAR (se muestra)
  'whatsapp'  => '56900000000',                              // <-- EDITAR: solo números con 56, sin + (agendamiento)
  'email'     => 'brisasdelnorteuv8@gmail.com',
  'logo'      => 'assets/img/logo.png',                      // <-- reemplaza el archivo por tu logo (PNG)
];

// ---- Carrusel de Inicio: archivos dentro de la carpeta /inicio --------
$CARRUSEL = [
  'foto1.jpg',   // <-- EDITAR: agrega o quita líneas con los nombres de tus fotos
  'foto2.jpg',
  'foto3.jpg',
];

// ---- Directiva: fotos dentro de la carpeta /directiva -----------------
$DIRECTIVA = [
  ['cargo'=>'Presidente',  'nombre'=>'Nombre Apellido', 'foto'=>'presidente.jpg',
   'bio'=>'Breve biografía del presidente. Escribe aquí 2 o 3 líneas.'],
  ['cargo'=>'Secretaria',  'nombre'=>'Nombre Apellido', 'foto'=>'secretaria.jpg',
   'bio'=>'Breve biografía de la secretaria.'],
  ['cargo'=>'Tesorera',    'nombre'=>'Nombre Apellido', 'foto'=>'tesorera.jpg',
   'bio'=>'Breve biografía de la tesorera.'],
  ['cargo'=>'Directora',   'nombre'=>'Nombre Apellido', 'foto'=>'directora.jpg',
   'bio'=>'Breve biografía de la directora.'],
];

// ---- Tipos de noticia -------------------------------------------------
$TIPOS_NOTICIA = ['Seguridad', 'Avisos Comunitarios', 'Asambleas'];

// ---- Tarifas (comprobantes) -------------------------------------------
define('PRECIO_CANCHA_HORA', 8000);
define('PRECIO_SEDE',        100000);   // valor final del arriendo
define('DEPOSITO_SEDE',      120000);   // monto a depositar (solo informativo)
define('CANCHA_HORA_INICIO', 19);       // desde esta hora (19:00) se arrienda
