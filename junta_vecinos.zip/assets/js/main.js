(() => {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* ---- Carrusel: cambia cada 6 s con fundido lento (CSS) ---- */
const sl = $$('.slide');
if (sl.length > 1) { let i = 0; setInterval(() => { sl[i].classList.remove('active'); i = (i + 1) % sl.length; sl[i].classList.add('active'); }, 6000); }

/* ---- Zoom de imágenes (directiva, galerías, condiciones) ---- */
const zoom = new bootstrap.Modal('#zoomModal');
function openZoom(el) { $('#zoomImg').src = el.dataset.zoom; zoom.show(); }
document.addEventListener('click', e => { const z = e.target.closest('[data-zoom]'); if (z) openZoom(z); });
document.addEventListener('keydown', e => { if (e.key === 'Enter') { const z = e.target.closest?.('[data-zoom]'); if (z) openZoom(z); } });
$('#zoomModal').addEventListener('hidden.bs.modal', () => $('#zoomImg').removeAttribute('src'));

/* ---- Noticias: filtro, "ver más" y modal ---- */
const items = $$('.news-item'), PAGE = 6; let filter = 'all', shown = PAGE;
function renderNews() {
  const vis = items.filter(it => filter === 'all' || it.dataset.type === filter);
  items.forEach(it => it.classList.add('d-none'));
  vis.slice(0, shown).forEach(it => it.classList.remove('d-none'));
  $('#newsMore')?.classList.toggle('d-none', vis.length <= shown);
  $('#newsEmpty')?.classList.toggle('d-none', vis.length > 0 || !items.length);
}
$$('#newsFilters [data-filter]').forEach(b => b.addEventListener('click', () => {
  $$('#newsFilters .btn').forEach(x => x.classList.remove('active')); b.classList.add('active');
  filter = b.dataset.filter; shown = PAGE; renderNews();
}));
$('#newsMore')?.addEventListener('click', () => { shown += PAGE; renderNews(); });
renderNews();
const nm = new bootstrap.Modal('#newsModal');
function openNews(id) {
  const d = $('#nb-' + id); if (!d) return;
  $('#nmTitle').textContent = d.dataset.title; $('#nmType').textContent = d.dataset.type; $('#nmDate').textContent = d.dataset.date;
  $('#nmBody').innerHTML = d.innerHTML;
  $('#nmMedia').innerHTML = d.dataset.mtype === 'video'
    ? `<video src="${d.dataset.media}" controls playsinline preload="metadata"></video>` : `<img src="${d.dataset.media}" alt="">`;
  nm.show();
}
$$('[data-news]').forEach(c => { c.addEventListener('click', () => openNews(c.dataset.news));
  c.addEventListener('keydown', e => { if (e.key === 'Enter') openNews(c.dataset.news); }); });
$('#newsModal').addEventListener('hidden.bs.modal', () => $('#nmMedia').innerHTML = '');

/* ---- Contacto: validación, captcha y envío ---- */
const f = $('#contactForm'), mm = new bootstrap.Modal('#msgModal');
const msg = (t, b) => { $('#msgTitle').textContent = t; $('#msgBody').textContent = b; mm.show(); };
async function loadCaptcha() {
  try { const r = await fetch('/captcha.php', { cache: 'no-store' }); $('#capQ').textContent = (await r.json()).q; $('#c_c').value = ''; } catch (_) { $('#capQ').textContent = 'No se pudo cargar la verificación'; }
}
loadCaptcha(); $('#capRefresh').addEventListener('click', loadCaptcha);
f.addEventListener('submit', async e => {
  e.preventDefault(); f.classList.add('was-validated');
  if (!f.checkValidity()) return;
  const btn = $('#sendBtn'); btn.disabled = true; btn.textContent = 'Enviando…';
  try {
    const r = await fetch('/contact.php', { method: 'POST', body: new FormData(f) }), j = await r.json();
    if (j.ok) { msg('Mensaje enviado', j.msg); f.reset(); f.classList.remove('was-validated'); }
    else msg('No se pudo enviar', j.msg || 'Inténtalo nuevamente.');
  } catch (_) { msg('Sin conexión', 'No se pudo enviar el mensaje. Revisa tu conexión.'); }
  btn.disabled = false; btn.textContent = 'Enviar mensaje'; loadCaptcha();
});
})();
