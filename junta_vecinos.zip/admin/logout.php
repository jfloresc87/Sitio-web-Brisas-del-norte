<?php
require __DIR__.'/../includes/bootstrap.php';
$_SESSION = []; session_destroy(); header('Location: /admin/login.php'); exit;
