<?php
/* INSTALADOR: ejecútalo UNA vez en /install.php?key=TU_INSTALL_KEY y luego BORRA este archivo. */
require __DIR__.'/includes/bootstrap.php';
header('Content-Type: text/plain; charset=utf-8');
if (!hash_equals(INSTALL_KEY, $_GET['key'] ?? '')) { http_response_code(403); exit('Clave de instalación incorrecta.'); }
try {
  $w = db(DB_WEB);
  $w->exec("CREATE TABLE IF NOT EXISTS users(
    id INT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(120) NOT NULL UNIQUE, pass_hash VARCHAR(255) NOT NULL,
    must_change TINYINT NOT NULL DEFAULT 1, reset_hash CHAR(64) NULL, reset_expires DATETIME NULL, last_login DATETIME NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $w->exec("CREATE TABLE IF NOT EXISTS login_attempts(
    id INT AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(45) NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY(ip)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $w->exec("CREATE TABLE IF NOT EXISTS news(
    id INT AUTO_INCREMENT PRIMARY KEY, type VARCHAR(40) NOT NULL, title VARCHAR(150) NOT NULL, seo VARCHAR(300) NOT NULL,
    body MEDIUMTEXT NOT NULL, media_path VARCHAR(255) NOT NULL, media_type VARCHAR(10) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, author VARCHAR(120) NULL, KEY(created_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $w->exec("CREATE TABLE IF NOT EXISTS services(
    id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(120) NOT NULL, price_text VARCHAR(120) NULL, description TEXT NULL,
    whatsapp TINYINT NOT NULL DEFAULT 0, cond_image VARCHAR(255) NULL, gallery TEXT NULL, sort_order INT NOT NULL DEFAULT 0
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $r = db(DB_REC);
  $r->exec("CREATE TABLE IF NOT EXISTS receipts(
    id INT AUTO_INCREMENT PRIMARY KEY,               -- N° de comprobante correlativo
    concept VARCHAR(30) NOT NULL, name VARCHAR(60) NOT NULL, lastname VARCHAR(60) NOT NULL,
    phone VARCHAR(20) NULL, rut VARCHAR(14) NULL, other_concept VARCHAR(150) NULL,
    hour_start TINYINT NULL, hour_qty TINYINT NULL, method VARCHAR(15) NOT NULL,
    special TINYINT NOT NULL DEFAULT 0, amount INT NOT NULL, event_date DATE NULL,
    issued_at DATETIME NOT NULL, issued_by VARCHAR(120) NOT NULL, KEY(issued_at)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

  $h = password_hash('Brisas2016.', PASSWORD_DEFAULT);
  foreach (['jesus.flores.ci@gmail.com','vprobosteo@gmail.com','brisasdelnorteuv8@gmail.com'] as $m)
    $w->prepare("INSERT IGNORE INTO users(email,pass_hash,must_change) VALUES(?,?,1)")->execute([$m, $h]);

  if (!$w->query("SELECT COUNT(*) FROM services")->fetchColumn()) {
    $s = $w->prepare("INSERT INTO services(title,price_text,description,whatsapp,sort_order) VALUES(?,?,?,?,?)");
    $s->execute(['Arriendo de Cancha','$8.000 la hora',"Horarios desde las 19:00 hrs, en horas completas.\nAgenda tu hora por WhatsApp.",1,1]);
    $s->execute(['Arriendo de Sede','$100.000',"Escribe aquí las condiciones del arriendo (también puedes subir una imagen con las condiciones).",1,2]);
    $s->execute(['Certificados de residencia','',"Revisa las condiciones y la dirección de retiro.",0,3]);
  }
  echo "OK: tablas creadas y usuarios cargados.\nClave inicial: Brisas2016. (se exige cambiarla al primer ingreso)\n\nIMPORTANTE: borra ahora el archivo install.php del servidor.";
} catch (Throwable $e) { http_response_code(500); echo 'ERROR: '.$e->getMessage(); }
